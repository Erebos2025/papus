package com.atunesdelpacifico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtunesdelpacificoApplicationTests {

	@Test
	void contextLoads() {
	}

}
